
drop table Transporte;
drop table Vehiculo;
drop table Transportista;
drop table Administrativo;
drop table Empleado;
drop table Oficina;
drop table Sucursal;

create table Sucursal(Nom_sucursal varchar2(25) primary key,
                        Region varchar2(25));
                        
create table Oficina(Cod_interno number(4),
                    Nom_sucursal varchar2(25) references Sucursal(Nom_sucursal),
                    DNI_responsable number(8),
                    constraint PK_Oficina primary key (Cod_interno,Nom_sucursal)
                    );

create table Empleado(DNI number(8) primary key,
                        Nom_completo varchar2 (40),
                        Fecha_incorporacion varchar2(10),
                        Fecha_nacimiento varchar2(10)
                        );

create table Administrativo(DNI number(8) primary key references Empleado(DNI),
                            Cod_interno number(4),
                            Nom_sucursal varchar2(25),
                            constraint FK_Administrativo foreign key (Cod_interno,Nom_sucursal)
                            references Oficina(Cod_interno,Nom_sucursal)
                            );
alter table Oficina add constraint FK_Oficina foreign key (DNI_responsable) references Administrativo(DNI);
                            
create table Transportista(DNI number(8) primary key references Empleado(DNI));

create table Vehiculo(Matricula varchar2(7) primary key,
                        Capacidad_deposito number(5));
                        
create table Transporte(Cod_transporte varchar2(10) primary key,
                        Km number(8),
                        DNI number(8) references Transportista(DNI),
                        Matricula varchar2(7) references Vehiculo(Matricula)
                        );
                        
create role Administrativo;
grant connect,resource to Administrativo;
grant all privileges on Empleado to Administrativo;
grant all privileges on Oficina to Administrativo;
grant all privileges on Sucursal to Administrativo;
drop role Administrativo;                       

create role Transportista;
grant connect, resource to Transportista;
grant select, alter on Vehiculo to Transportista;
grant select, alter on Transporte to Transportista;
drop role Transportista;

create user Conductor1 identified by Contr1;
grant Transportista to Conductor1;

create user Contable1 identified by Contr2;
grant Administrativo to Contable1;

create user Gestor identified by Contr3;
grant all privileges on Empleado to Gestor;
grant all privileges on Oficina to Gestor;
grant all privileges on Sucursal to Gestor;
grant all privileges on Vehiculo to Gestor;
grant all privileges on Administrativo to Gestor;
grant all privileges on Transporte to Gestor;
grant all privileges on Transportista to Gestor;
drop user Gestor;














